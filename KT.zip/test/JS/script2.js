var typed = new Typed(".typed-text",{
    strings: [,  "Designer", "Developer", "Freelancer", "Photographer"] ,
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 2000,
    loop: true    
    })